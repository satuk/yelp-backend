package com.propulsion.yelp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YelpApplication {

	public static void main(String[] args) {
		SpringApplication.run(YelpApplication.class, args);
	}
}
